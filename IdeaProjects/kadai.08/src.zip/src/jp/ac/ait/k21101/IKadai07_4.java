package jp.ac.ait.k21101;

import java.util.List;

public interface IKadai07_4 {
    void convert(List<Integer> targetList);
}
