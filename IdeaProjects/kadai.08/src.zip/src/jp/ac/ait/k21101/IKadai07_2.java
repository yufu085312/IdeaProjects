package jp.ac.ait.k21101;

import java.util.List;

public interface IKadai07_2 {
    List<String> getConverted(List<Integer> targetList);
}
